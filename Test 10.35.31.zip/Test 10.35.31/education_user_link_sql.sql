-- SQL Script để cập nhật bảng Education với UserID

-- Kiểm tra và thêm cột UserID vào bảng Education nếu chưa có
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Education') AND name = 'UserID')
BEGIN
    ALTER TABLE Education 
    ADD UserID INT NOT NULL DEFAULT(0);
    
    -- Tạo foreign key constraint
    ALTER TABLE Education 
    ADD CONSTRAINT FK_Education_User 
    FOREIGN KEY (UserID) REFERENCES Users(Id);
    
    PRINT 'Added UserID column and foreign key constraint to Education table';
END
ELSE
BEGIN
    PRINT 'UserID column already exists in Education table';
END

-- Tạo index cho UserID để tối ưu query
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Education_UserID' AND object_id = OBJECT_ID('Education'))
BEGIN
    CREATE NONCLUSTERED INDEX IX_Education_UserID ON Education(UserID);
    PRINT 'Created index IX_Education_UserID';
END

-- Cập nhật View EducationView để bao gồm thông tin User
CREATE OR ALTER VIEW EducationView AS
SELECT 
    e.Id,
    e.UserID,
    u_user.Email AS UserEmail,
    CONCAT(u_user.FirstName, ' ', u_user.LastName) AS UserFullName,
    e.UniversityID,
    u_uni.UniversityName,
    e.MajorID,
    m.MajorName,
    e.DegreeID,
    d.DegreeName,
    e.Location,
    e.GPA,
    e.OutOf,
    e.GraduationMonth,
    e.GraduationYear,
    e.CreatedAt,
    e.UpdatedAt,
    e.DeletedAt,
    CONCAT(FORMAT(e.GPA, 'F2'), '/', FORMAT(e.OutOf, 'F2')) AS GPAFormatted,
    CONCAT(
        CASE e.GraduationMonth
            WHEN 'January' THEN '01'
            WHEN 'February' THEN '02'
            WHEN 'March' THEN '03'
            WHEN 'April' THEN '04'
            WHEN 'May' THEN '05'
            WHEN 'June' THEN '06'
            WHEN 'July' THEN '07'
            WHEN 'August' THEN '08'
            WHEN 'September' THEN '09'
            WHEN 'October' THEN '10'
            WHEN 'November' THEN '11'
            WHEN 'December' THEN '12'
        END,
        '/',
        e.GraduationYear
    ) AS FormattedGraduationDate
FROM Education e
INNER JOIN Users u_user ON e.UserID = u_user.Id
INNER JOIN University u_uni ON e.UniversityID = u_uni.Id
INNER JOIN Major m ON e.MajorID = m.Id  
INNER JOIN Degree d ON e.DegreeID = d.Id
WHERE e.DeletedAt IS NULL AND u_user.DeletedAt IS NULL;

-- Stored Procedure để lấy Education theo UserID
CREATE OR ALTER PROCEDURE sp_GetEducationByUserId
    @UserID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        e.*,
        u.UniversityName,
        m.MajorName,
        d.DegreeName
    FROM Education e
    INNER JOIN University u ON e.UniversityID = u.Id
    INNER JOIN Major m ON e.MajorID = m.Id
    INNER JOIN Degree d ON e.DegreeID = d.Id
    WHERE e.UserID = @UserID 
    AND e.DeletedAt IS NULL
    ORDER BY e.CreatedAt DESC;
END

-- Stored Procedure để thêm Education
CREATE OR ALTER PROCEDURE sp_AddEducation
    @UserID INT,
    @UniversityID INT,
    @MajorID INT,
    @DegreeID INT,
    @Location NVARCHAR(255),
    @GPA DECIMAL(3,2),
    @OutOf DECIMAL(3,2),
    @GraduationMonth NVARCHAR(20),
    @GraduationYear INT
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Validate input
    IF NOT EXISTS (SELECT 1 FROM Users WHERE Id = @UserID AND DeletedAt IS NULL)
    BEGIN
        RAISERROR('User not found or inactive', 16, 1);
        RETURN;
    END
    
    IF NOT EXISTS (SELECT 1 FROM University WHERE Id = @UniversityID)
    BEGIN
        RAISERROR('University not found', 16, 1);
        RETURN;
    END
    
    IF NOT EXISTS (SELECT 1 FROM Major WHERE Id = @MajorID)
    BEGIN
        RAISERROR('Major not found', 16, 1);
        RETURN;
    END
    
    IF NOT EXISTS (SELECT 1 FROM Degree WHERE Id = @DegreeID)
    BEGIN
        RAISERROR('Degree not found', 16, 1);
        RETURN;
    END
    
    -- Insert education record
    INSERT INTO Education (
        UserID, UniversityID, MajorID, DegreeID, 
        Location, GPA, OutOf, GraduationMonth, GraduationYear, 
        CreatedAt
    )
    VALUES (
        @UserID, @UniversityID, @MajorID, @DegreeID,
        @Location, @GPA, @OutOf, @GraduationMonth, @GraduationYear,
        GETDATE()
    );
    
    SELECT SCOPE_IDENTITY() AS NewEducationId;
END

-- Stored Procedure để xóa Education (soft delete)
CREATE OR ALTER PROCEDURE sp_DeleteEducation
    @EducationID INT,
    @UserID INT = NULL -- Optional: để verify ownership
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Verify education exists and belongs to user (if UserID provided)
    IF @UserID IS NOT NULL
    BEGIN
        IF NOT EXISTS (
            SELECT 1 FROM Education 
            WHERE Id = @EducationID 
            AND UserID = @UserID 
            AND DeletedAt IS NULL
        )
        BEGIN
            RAISERROR('Education record not found or access denied', 16, 1);
            RETURN;
        END
    END
    ELSE
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM Education WHERE Id = @EducationID AND DeletedAt IS NULL)
        BEGIN
            RAISERROR('Education record not found', 16, 1);
            RETURN;
        END
    END
    
    -- Soft delete
    UPDATE Education 
    SET DeletedAt = GETDATE(), UpdatedAt = GETDATE()
    WHERE Id = @EducationID;
    
    SELECT 1 AS Success;
END

-- Function để đếm số Education records của một User
CREATE OR ALTER FUNCTION fn_GetEducationCountByUser(@UserID INT)
RETURNS INT
AS
BEGIN
    DECLARE @Count INT;
    
    SELECT @Count = COUNT(*)
    FROM Education
    WHERE UserID = @UserID AND DeletedAt IS NULL;
    
    RETURN ISNULL(@Count, 0);
END

-- Trigger để log Education changes
CREATE OR ALTER TRIGGER trg_Education_Audit
ON Education
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Create audit table if not exists
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE name = 'EducationAudit' AND type = 'U')
    BEGIN
        CREATE TABLE EducationAudit (
            AuditID INT IDENTITY(1,1) PRIMARY KEY,
            EducationID INT,
            UserID INT,
            Action NVARCHAR(10), -- INSERT, UPDATE, DELETE
            OldValues NVARCHAR(MAX),
            NewValues NVARCHAR(MAX),
            ChangedBy NVARCHAR(255),
            ChangeDate DATETIME2 DEFAULT GETDATE()
        );
    END
    
    -- Log the changes
    IF EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
    BEGIN
        -- UPDATE
        INSERT INTO EducationAudit (EducationID, UserID, Action, ChangedBy)
        SELECT i.Id, i.UserID, 'UPDATE', SYSTEM_USER
        FROM inserted i;
    END
    ELSE IF EXISTS (SELECT * FROM inserted)
    BEGIN
        -- INSERT
        INSERT INTO EducationAudit (EducationID, UserID, Action, ChangedBy)
        SELECT i.Id, i.UserID, 'INSERT', SYSTEM_USER
        FROM inserted i;
    END
    ELSE IF EXISTS (SELECT * FROM deleted)
    BEGIN
        -- DELETE (soft delete - actually UPDATE)
        INSERT INTO EducationAudit (EducationID, UserID, Action, ChangedBy)
        SELECT d.Id, d.UserID, 'DELETE', SYSTEM_USER
        FROM deleted d;
    END
END

-- Test data để kiểm tra (chạy sau khi có Users)
/*
-- Uncomment để test sau khi có dữ liệu Users
DECLARE @TestUserID INT = 1; -- Thay bằng ID user thực tế

-- Test thêm education
EXEC sp_AddEducation 
    @UserID = @TestUserID,
    @UniversityID = 1,
    @MajorID = 1, 
    @DegreeID = 4,
    @Location = 'Cambridge, MA',
    @GPA = 3.85,
    @OutOf = 4.0,
    @GraduationMonth = 'May',
    @GraduationYear = 2023;

-- Test lấy education by user
EXEC sp_GetEducationByUserId @UserID = @TestUserID;

-- Test đếm education
SELECT dbo.fn_GetEducationCountByUser(@TestUserID) AS EducationCount;
*/

PRINT 'Education table updated successfully with UserID relationship!';
PRINT 'Views, stored procedures, functions and triggers created!';
PRINT 'Remember to run test queries after inserting Users data!';

-- Grant permissions (adjust as needed)
-- GRANT SELECT, INSERT, UPDATE ON Education TO [YourApplicationRole];
-- GRANT EXECUTE ON sp_GetEducationByUserId TO [YourApplicationRole];
-- GRANT EXECUTE ON sp_AddEducation TO [YourApplicationRole];
-- GRANT EXECUTE ON sp_DeleteEducation TO [YourApplicationRole];