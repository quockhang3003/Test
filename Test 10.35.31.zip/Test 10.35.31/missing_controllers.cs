// 1. Cập nhật EducationController.cs
using Domain.DTO;
using Domain.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EducationController : ControllerBase
    {
        private readonly EducationService _service;

        public EducationController(EducationService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var educations = await _service.GetAllAsync();
                return Ok(educations);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var education = await _service.GetByIdAsync(id);
                if (education == null)
                    return NotFound("Education record not found");

                return Ok(education);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddEducation(EducationDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                await _service.AddEducation(dto);
                return Ok(new { message = "Education added successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEducation(int id, EducationDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                await _service.UpdateEducation(id, dto);
                return Ok(new { message = "Education updated successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEducation(int id)
        {
            try
            {
                await _service.DeleteEducation(id);
                return Ok(new { message = "Education deleted successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}

// 2. Cập nhật MajorController.cs
using Microsoft.AspNetCore.Mvc;
using Service;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MajorController : ControllerBase
    {
        private readonly MajorService _service;
        
        public MajorController(MajorService service)
        {
            _service = service;
        }
        
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var majors = await _service.GetAllAsync();
                return Ok(majors);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

// 3. Cập nhật DegreeController.cs
using Microsoft.AspNetCore.Mvc;
using Service;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DegreeController : ControllerBase
    {
        private readonly DegreeService _service;
        
        public DegreeController(DegreeService service)
        {
            _service = service;
        }
        
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var degrees = await _service.GetAllAsync();
                return Ok(degrees);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

// 4. Cập nhật UniversityController.cs
using Microsoft.AspNetCore.Mvc;
using Service;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]  
    public class UniversityController : ControllerBase
    {
        private readonly UniversityService _service;
        
        public UniversityController(UniversityService service)
        {
            _service = service;
        }
        
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var universities = await _service.GetAllAsync();
                return Ok(universities);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

// 5. Cập nhật EducationService.cs
using Domain.DTO;
using Domain.Entities;
using Domain.Interfaces;

namespace Service
{
    public class EducationService
    {
        private readonly IEducationRepository _repo;
        
        public EducationService(IEducationRepository repo)
        {
            _repo = repo;
        }
        
        public async Task<IEnumerable<Education>> GetAllAsync() => await _repo.GetAllAsync();
        
        public async Task<Education?> GetByIdAsync(int id) => await _repo.GetByIdAsync(id);
        
        public async Task AddEducation(EducationDTO dto)
        { 
            var education = new Education
            {
                UniversityID = dto.UniversityID.Value,
                MajorID = dto.MajorID.Value,
                DegreeID = dto.DegreeID.Value,
                Location = dto.Location,
                GPA = dto.GPA,
                OutOf = dto.OutOf,
                GraduationMonth = dto.GraduationMonth,
                GraduationYear = dto.GraduationYear,
                CreatedAt = DateTime.UtcNow
            };
            await _repo.AddAsync(education);
        }

        public async Task UpdateEducation(int id, EducationDTO dto)
        {
            var education = new Education
            {
                Id = id,
                UniversityID = dto.UniversityID.Value,
                MajorID = dto.MajorID.Value,
                DegreeID = dto.DegreeID.Value,
                Location = dto.Location,
                GPA = dto.GPA,
                OutOf = dto.OutOf,
                GraduationMonth = dto.GraduationMonth,
                GraduationYear = dto.GraduationYear,
                UpdatedAt = DateTime.UtcNow
            };
            await _repo.UpdateAsync(education);
        }

        public async Task DeleteEducation(int id)
        {
            await _repo.DeleteAsync(id);
        }
    }
}

// 6. Cập nhật IEducationRepository.cs interface
using Domain.Entities;

namespace Domain.Interfaces
{
    public interface IEducationRepository
    {
        Task<IEnumerable<Education>> GetAllAsync();
        Task<Education?> GetByIdAsync(int id);
        Task AddAsync(Education education);
        Task UpdateAsync(Education education);
        Task DeleteAsync(int id);
    }
}

// 7. Cập nhật EducationRepository.cs
using Dapper;
using Domain.Entities;
using Domain.Interfaces;

namespace DataAccess
{
    public class EducationRepository : IEducationRepository
    {
        private readonly IDbConnectionFactory _dbFactory;
        
        public EducationRepository(IDbConnectionFactory dbFactory)
        {
            _dbFactory = dbFactory;
        }

        public async Task<IEnumerable<Education>> GetAllAsync()
        {
            using var conn = _dbFactory.CreateConnection();
            var sql = "SELECT * FROM Education WHERE DeletedAt IS NULL ORDER BY CreatedAt DESC";
            return await conn.QueryAsync<Education>(sql);
        }

        public async Task<Education?> GetByIdAsync(int id)
        {
            using var conn = _dbFactory.CreateConnection();
            var sql = "SELECT * FROM Education WHERE Id = @Id AND DeletedAt IS NULL";
            return await conn.QueryFirstOrDefaultAsync<Education>(sql, new { Id = id });
        }

        public async Task AddAsync(Education education)
        {
            using var conn = _dbFactory.CreateConnection();
            var sql = @"INSERT INTO Education (
                            UniversityID, MajorID, DegreeID, Location, GPA, OutOf,
                            GraduationMonth, GraduationYear, CreatedAt) 
                        VALUES (
                            @UniversityID, @MajorID, @DegreeID, @Location, @GPA, @OutOf,
                            @GraduationMonth, @GraduationYear, @CreatedAt)";
            await conn.ExecuteAsync(sql, education);
        }

        public async Task UpdateAsync(Education education)
        {
            using var conn = _dbFactory.CreateConnection();
            var sql = @"UPDATE Education SET
                            UniversityID = @UniversityID,
                            MajorID = @MajorID,
                            DegreeID = @DegreeID,
                            Location = @Location,
                            GPA = @GPA,
                            OutOf = @OutOf,
                            GraduationMonth = @GraduationMonth,
                            GraduationYear = @GraduationYear,
                            UpdatedAt = @UpdatedAt
                        WHERE Id = @Id AND DeletedAt IS NULL";
            await conn.ExecuteAsync(sql, education);
        }

        public async Task DeleteAsync(int id)
        {
            using var conn = _dbFactory.CreateConnection();
            var sql = "UPDATE Education SET DeletedAt = @DeletedAt WHERE Id = @Id";
            await conn.ExecuteAsync(sql, new { Id = id, DeletedAt = DateTime.UtcNow });
        }
    }
}

// 8. Sửa lỗi UniversityRepository.cs (có lỗi typo "FORM" thành "FROM")
using Dapper;
using Domain.Entities;
using Domain.Interfaces;

namespace DataAccess
{
    public class UniversityRepository : IUniversityRepository
    {
        private readonly IDbConnectionFactory _dbFactory;
        
        public UniversityRepository(IDbConnectionFactory dbFactory)
        {
            _dbFactory = dbFactory;
        }

        public async Task<IEnumerable<University>> GetAllAsync()
        {
            using var conn = _dbFactory.CreateConnection();
            return await conn.QueryAsync<University>("SELECT * FROM University");
        }
    }
}