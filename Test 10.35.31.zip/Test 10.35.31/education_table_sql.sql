-- SQL Script để tạo bảng Education và các bảng liên quan

-- Tạo bảng University nếu chưa có
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='University' AND xtype='U')
CREATE TABLE University (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UniversityName NVARCHAR(255) NOT NULL,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 NULL,
    DeletedAt DATETIME2 NULL
);

-- Tạo bảng Major nếu chưa có
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Major' AND xtype='U')
CREATE TABLE Major (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    MajorName NVARCHAR(255) NOT NULL,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 NULL,
    DeletedAt DATETIME2 NULL
);

-- Tạo bảng Degree nếu chưa có
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Degree' AND xtype='U')
CREATE TABLE Degree (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    DegreeName NVARCHAR(255) NOT NULL,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 NULL,
    DeletedAt DATETIME2 NULL
);

-- Tạo bảng Education
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Education' AND xtype='U')
CREATE TABLE Education (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UniversityID INT NOT NULL,
    MajorID INT NOT NULL,
    DegreeID INT NOT NULL,
    Location NVARCHAR(255) NOT NULL,
    GPA DECIMAL(3,2) NOT NULL,
    OutOf DECIMAL(3,2) NOT NULL,
    GraduationMonth NVARCHAR(20) NOT NULL,
    GraduationYear INT NOT NULL,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 NULL,
    DeletedAt DATETIME2 NULL,
    
    -- Foreign Key Constraints
    CONSTRAINT FK_Education_University FOREIGN KEY (UniversityID) REFERENCES University(Id),
    CONSTRAINT FK_Education_Major FOREIGN KEY (MajorID) REFERENCES Major(Id),
    CONSTRAINT FK_Education_Degree FOREIGN KEY (DegreeID) REFERENCES Degree(Id),
    
    -- Check Constraints
    CONSTRAINT CK_Education_GPA CHECK (GPA >= 0 AND GPA <= OutOf),
    CONSTRAINT CK_Education_OutOf CHECK (OutOf > 0),
    CONSTRAINT CK_Education_GraduationYear CHECK (GraduationYear >= 1900 AND GraduationYear <= 2050)
);

-- Thêm dữ liệu mẫu cho University
IF NOT EXISTS (SELECT * FROM University)
BEGIN
    INSERT INTO University (UniversityName) VALUES 
    ('Harvard University'),
    ('Stanford University'),
    ('Massachusetts Institute of Technology (MIT)'),
    ('Oxford University'),
    ('Cambridge University'),
    ('University of California, Berkeley'),
    ('California Institute of Technology (Caltech)'),
    ('Princeton University'),
    ('Yale University'),
    ('University of Chicago'),
    ('National University of Singapore (NUS)'),
    ('Nanyang Technological University (NTU)'),
    ('University of Melbourne'),
    ('Australian National University (ANU)'),
    ('University of Sydney'),
    ('University of Tokyo'),
    ('Kyoto University'),
    ('Seoul National University'),
    ('KAIST'),
    ('Acleda University'),
    ('Royal University of Phnom Penh'),
    ('University of Cambodia'),
    ('Norton University'),
    ('International University'),
    ('Pannasastra University'),
    ('Ho Chi Minh City University of Technology'),
    ('Hanoi University of Science and Technology'),
    ('Vietnam National University'),
    ('Foreign Trade University'),
    ('University of Economics Ho Chi Minh City');
END

-- Thêm dữ liệu mẫu cho Major
IF NOT EXISTS (SELECT * FROM Major)
BEGIN
    INSERT INTO Major (MajorName) VALUES 
    ('Accounting'),
    ('Finance'),
    ('Business Administration'),
    ('Economics'),
    ('Computer Science'),
    ('Information Technology'),
    ('Software Engineering'),
    ('Data Science'),
    ('Artificial Intelligence'),
    ('Mechanical Engineering'),
    ('Electrical Engineering'),
    ('Civil Engineering'),
    ('Chemical Engineering'),
    ('Industrial Engineering'),
    ('Marketing'),
    ('Management'),
    ('International Business'),
    ('Banking and Finance'),
    ('Mathematics'),
    ('Statistics'),
    ('Physics'),
    ('Chemistry'),
    ('Biology'),
    ('Psychology'),
    ('Law'),
    ('Medicine'),
    ('Pharmacy'),
    ('Architecture'),
    ('Design'),
    ('Communications');
END

-- Thêm dữ liệu mẫu cho Degree
IF NOT EXISTS (SELECT * FROM Degree)
BEGIN
    INSERT INTO Degree (DegreeName) VALUES 
    ('High School Diploma'),
    ('Associate Degree'),
    ('Bachelor of Arts (BA)'),
    ('Bachelor of Science (BS)'),
    ('Bachelor of Business Administration (BBA)'),
    ('Bachelor of Engineering (BE)'),
    ('Bachelor of Technology (BTech)'),
    ('Bachelor of Commerce (BCom)'),
    ('Master of Arts (MA)'),
    ('Master of Science (MS)'),
    ('Master of Business Administration (MBA)'),
    ('Master of Engineering (ME)'),
    ('Master of Technology (MTech)'),
    ('Master of Finance (MFin)'),
    ('Master of Accounting (MAcc)'),
    ('Doctor of Philosophy (PhD)'),
    ('Doctor of Medicine (MD)'),
    ('Doctor of Business Administration (DBA)'),
    ('Juris Doctor (JD)'),
    ('Certificate'),
    ('Diploma'),
    ('Professional Certificate');
END

-- Tạo indexes để tối ưu hiệu suất
CREATE NONCLUSTERED INDEX IX_Education_UniversityID ON Education(UniversityID);
CREATE NONCLUSTERED INDEX IX_Education_MajorID ON Education(MajorID);
CREATE NONCLUSTERED INDEX IX_Education_DegreeID ON Education(DegreeID);
CREATE NONCLUSTERED INDEX IX_Education_DeletedAt ON Education(DeletedAt);
CREATE NONCLUSTERED INDEX IX_Education_CreatedAt ON Education(CreatedAt DESC);

-- Thêm computed column để tính graduation date
ALTER TABLE Education 
ADD GraduationDate AS (
    CASE 
        WHEN GraduationMonth = 'January' THEN DATEFROMPARTS(GraduationYear, 1, 1)
        WHEN GraduationMonth = 'February' THEN DATEFROMPARTS(GraduationYear, 2, 1)
        WHEN GraduationMonth = 'March' THEN DATEFROMPARTS(GraduationYear, 3, 1)
        WHEN GraduationMonth = 'April' THEN DATEFROMPARTS(GraduationYear, 4, 1)
        WHEN GraduationMonth = 'May' THEN DATEFROMPARTS(GraduationYear, 5, 1)
        WHEN GraduationMonth = 'June' THEN DATEFROMPARTS(GraduationYear, 6, 1)
        WHEN GraduationMonth = 'July' THEN DATEFROMPARTS(GraduationYear, 7, 1)
        WHEN GraduationMonth = 'August' THEN DATEFROMPARTS(GraduationYear, 8, 1)
        WHEN GraduationMonth = 'September' THEN DATEFROMPARTS(GraduationYear, 9, 1)
        WHEN GraduationMonth = 'October' THEN DATEFROMPARTS(GraduationYear, 10, 1)
        WHEN GraduationMonth = 'November' THEN DATEFROMPARTS(GraduationYear, 11, 1)
        WHEN GraduationMonth = 'December' THEN DATEFROMPARTS(GraduationYear, 12, 1)
        ELSE DATEFROMPARTS(GraduationYear, 1, 1)
    END
) PERSISTED;

PRINT 'Education tables and sample data created successfully!';

-- View để hiển thị education với tên university, major, degree
CREATE OR ALTER VIEW EducationView AS
SELECT 
    e.Id,
    e.UniversityID,
    u.UniversityName,
    e.MajorID,
    m.MajorName,
    e.DegreeID,
    d.DegreeName,
    e.Location,
    e.GPA,
    e.OutOf,
    e.GraduationMonth,
    e.GraduationYear,
    e.GraduationDate,
    e.CreatedAt,
    e.UpdatedAt,
    e.DeletedAt,
    CONCAT(FORMAT(e.GPA, 'F2'), '/', FORMAT(e.OutOf, 'F2')) AS GPAFormatted,
    CONCAT(
        CASE e.GraduationMonth
            WHEN 'January' THEN '01'
            WHEN 'February' THEN '02'
            WHEN 'March' THEN '03'
            WHEN 'April' THEN '04'
            WHEN 'May' THEN '05'
            WHEN 'June' THEN '06'
            WHEN 'July' THEN '07'
            WHEN 'August' THEN '08'
            WHEN 'September' THEN '09'
            WHEN 'October' THEN '10'
            WHEN 'November' THEN '11'
            WHEN 'December' THEN '12'
        END,
        '/',
        e.GraduationYear
    ) AS FormattedGraduationDate
FROM Education e
INNER JOIN University u ON e.UniversityID = u.Id
INNER JOIN Major m ON e.MajorID = m.Id  
INNER JOIN Degree d ON e.DegreeID = d.Id
WHERE e.DeletedAt IS NULL;