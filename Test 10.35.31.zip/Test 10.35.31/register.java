@page "/register"
@rendermode InteractiveServer
@attribute [StreamRendering]
@using Domain.DTO
@using System.Text.Json
@using System.ComponentModel.DataAnnotations
@using Domain.Entities
@using Microsoft.AspNetCore.Components
@using Service
@inject IHttpClientFactory ClientFactory
@inject IJSRuntime jSRuntime
@inject CookieService CookieService
@inject UserService UserService
@inject NavigationManager Navigation

@* Existing loading and form code remains the same *@
@if (isLoading)
{
    <div class="text-center mt-5">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        <p>Loading form data...</p>
    </div>
}
else
{
    <PageTitle>Create Application</PageTitle>
    <EditForm Model="registerModel" OnValidSubmit="HandleValidSubmit" OnInvalidSubmit="HandleInvalidSubmit">
        @* All existing form content remains the same *@
        <DataAnnotationsValidator />
        <ValidationSummary />
        <div class="container mt-1">
            @* ... existing form content ... *@
            <div class="text-center col-sm-7 px-4 py-4">
                <button type="submit" class="btn btn-primary" disabled="@isSaving">
                    @if (isSaving)
                    {
                        <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                        <span>Saving...</span>
                    }
                    else
                    {
                        <span>Next</span>
                    }
                </button>
            </div>
            @if (!string.IsNullOrEmpty(submitMessage))
            {
                <div class="alert @(submitMessage.Contains("thành công") ? "alert-success" : "alert-danger")">
                    @submitMessage
                </div>
            }
        </div>
    </EditForm>
}

@code {
    [SupplyParameterFromForm]
    private RegisterDTO registerModel { get; set; } = new RegisterDTO();
    private User? userModel;
    private bool isLoading = true;
    private bool isSaving = false;
    private string submitMessage = string.Empty;
    private bool firstRender = true;
    private List<LocationOfficeDTO> locations = new();
    private List<PreferenceDTO> preference = new();
    private List<CityDTO> city = new();
    private HttpClient Http => ClientFactory.CreateClient("LocalAPI");

    // Existing OnAfterRenderAsync method remains the same
    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        // ... existing code ...
    }

    private async Task HandleValidSubmit()
    {
        isSaving = true;
        submitMessage = string.Empty;
        StateHasChanged();

        try
        {
            Console.WriteLine("HandleValidSubmit called!");
            var validationContext = new ValidationContext(registerModel);
            var validationResults = new List<ValidationResult>();
            bool isValid = Validator.TryValidateObject(registerModel, validationContext, validationResults, true);
            
            if (!isValid)
            {
                Console.WriteLine("Model is still invalid!");
                foreach (var error in validationResults)
                {
                    Console.WriteLine($"- {error.ErrorMessage}");
                }
                submitMessage = "Form validation failed. Please check all required fields.";
                return;
            }

            var apiModel = new
            {
                registerModel.ID,
                registerModel.LastName,
                registerModel.FirstName,
                registerModel.VietnameseName,
                registerModel.Gender,
                registerModel.Nationality,
                registerModel.DateOfBirth,
                registerModel.PlaceOfBirth,
                registerModel.Email,
                registerModel.IdCardNumber,
                registerModel.DateOfIssue,
                registerModel.PlaceOfIssue,
                registerModel.Mobile,
                registerModel.Street,
                registerModel.Ward,
                registerModel.CurrentAddress,
                registerModel.City,
                registerModel.PreferableOfficeLocation,
                registerModel.FirstPreference,
                registerModel.SecondPreference
            };
            
            Console.WriteLine("Sending data to API...");
            Console.WriteLine(JsonSerializer.Serialize(apiModel, new JsonSerializerOptions { WriteIndented = true }));
            
            var response = await Http.PostAsJsonAsync("api/User/register", apiModel);

            if (response.IsSuccessStatusCode)
            {
                submitMessage = "Lưu thành công! Đang chuyển đến bước tiếp theo...";
                StateHasChanged();
                
                // Delay một chút để user thấy thông báo thành công
                await Task.Delay(1500);
                
                // Redirect đến step 2
                Navigation.NavigateTo("/register/step2", forceLoad: false);
            }
            else
            {
                var errorMessage = await response.Content.ReadAsStringAsync();
                submitMessage = $"Lỗi: {errorMessage}";
                Console.WriteLine($"API Error: {errorMessage}");
            }
        }
        catch (Exception ex)
        {
            submitMessage = $"Lỗi: {ex.Message}";
            Console.WriteLine($"Exception: {ex.Message}");
            Console.WriteLine($"Stack trace: {ex.StackTrace}");
        }
        finally
        {
            isSaving = false;
            StateHasChanged();
        }
    }
    
    private void HandleInvalidSubmit()
    {
        Console.WriteLine("HandleInvalidSubmit called! Form is invalid.");
        var validationContext = new ValidationContext(registerModel);
        var validationResults = new List<ValidationResult>();
        Validator.TryValidateObject(registerModel, validationContext, validationResults, true);
        
        Console.WriteLine("Validation errors:");
        foreach (var error in validationResults)
        {
            Console.WriteLine($"- {error.ErrorMessage}");
        }
        submitMessage = "Form có lỗi validation. Vui lòng kiểm tra lại các trường bắt buộc.";
    }
}